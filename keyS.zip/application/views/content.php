<?php 
	include "home.php";
	include "cash.php";
	include "portfolio.php";
	include "potential.php";
	include "calculator.php";
?>
</div>
</body>